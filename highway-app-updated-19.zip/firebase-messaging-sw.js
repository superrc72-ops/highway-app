// ============================================================
// firebase-messaging-sw.js
// 앱이 화면에 안 떠 있을 때(백그라운드/종료 상태)도 푸시 알림을 받기 위한 서비스워커
//
// ⚠️ 배포 위치 중요: index.html과 같은 최상위 경로(루트)에 놓아야 합니다.
//    예: highway-app 저장소 최상위에 이 파일 그대로 업로드
//    (다른 폴더에 넣으면 알림이 안 옵니다)
// ============================================================

importScripts("https://www.gstatic.com/firebasejs/10.13.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.13.1/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyCap3KuS254fg0fuil495s1Yp3kpHFVFwA",
  authDomain: "wichiwichi.firebaseapp.com",
  projectId: "wichiwichi",
  storageBucket: "wichiwichi.firebasestorage.app",
  messagingSenderId: "325317787544",
  appId: "1:325317787544:web:1c044f4792a92b35adf5ed"
});

const messaging = firebase.messaging();

// 백그라운드 상태에서 푸시가 도착했을 때 알림으로 표시
messaging.onBackgroundMessage((payload) => {
  const title = payload.notification?.title || "지금 이 길";
  const body = payload.notification?.body || "";

  self.registration.showNotification(title, {
    body,
    icon: "/icon-192.png", // 기존 앱 아이콘 경로로 필요시 수정
    badge: "/icon-192.png",
    data: payload.data || {}
  });
});

// 알림을 탭했을 때 앱 열기
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ("focus" in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow("/");
    })
  );
});
