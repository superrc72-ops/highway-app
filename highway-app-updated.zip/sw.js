// ============================================================
// 지금 이 길 서비스워커
// - 기존 캐시 전략(network-first)은 그대로 유지
// - FCM 백그라운드 알림 처리를 이 파일 안에 병합함
//   (별도 firebase-messaging-sw.js를 쓰면 같은 scope에서 서비스워커가
//    충돌하므로, 하나의 서비스워커 안에서 같이 처리합니다)
// ============================================================

importScripts("https://www.gstatic.com/firebasejs/10.13.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.13.1/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyCap3KuS254fg0fuil495s1Yp3kpHFVFwA",
  authDomain: "wichiwichi.firebaseapp.com",
  projectId: "wichiwichi",
  storageBucket: "wichiwichi.firebasestorage.app",
  messagingSenderId: "325317787544",
  appId: "1:325317787544:web:1c044f4792a92b35adf5ed"
});

const messaging = firebase.messaging();

// 앱이 백그라운드/종료 상태일 때 푸시가 도착하면 알림으로 표시
messaging.onBackgroundMessage((payload) => {
  const title = payload.notification?.title || "지금 이 길";
  const body = payload.notification?.body || "";
  self.registration.showNotification(title, {
    body,
    icon: "/icon-192.png",
    badge: "/icon-192.png",
    data: payload.data || {}
  });
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ("focus" in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow("/");
    })
  );
});

// ------------------------------------------------------------
// 아래는 기존 캐시 로직 (수정 없음)
// ------------------------------------------------------------

const CACHE_NAME = "highway-app-v2";
const ASSETS = ["./", "./index.html", "./manifest.json"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  // API 호출은 항상 최신 데이터를 써야 하므로 캐시하지 않습니다
  if (event.request.url.includes("/api/")) return;

  // 네트워크를 항상 먼저 시도해서 최신 배포본을 받아오고,
  // 오프라인일 때만 캐시된 예전 버전을 보여줍니다.
  // (예전 cache-first 방식은 배포해도 화면이 안 바뀌는 문제가 있었습니다)
  // cache: "no-store"를 명시해서, 브라우저 자체 HTTP 캐시까지 건너뛰고
  // 매번 진짜 최신 파일을 받아오도록 확실히 합니다.
  event.respondWith(
    fetch(event.request, { cache: "no-store" })
      .then((res) => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, resClone));
        return res;
      })
      .catch(() => caches.match(event.request))
  );
});
