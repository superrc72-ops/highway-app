const CACHE_NAME = "highway-app-v2";
const ASSETS = ["./", "./index.html", "./manifest.json"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  // API 호출은 항상 최신 데이터를 써야 하므로 캐시하지 않습니다
  if (event.request.url.includes("/api/")) return;

  // 네트워크를 항상 먼저 시도해서 최신 배포본을 받아오고,
  // 오프라인일 때만 캐시된 예전 버전을 보여줍니다.
  // (예전 cache-first 방식은 배포해도 화면이 안 바뀌는 문제가 있었습니다)
  event.respondWith(
    fetch(event.request)
      .then((res) => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, resClone));
        return res;
      })
      .catch(() => caches.match(event.request))
  );
});
